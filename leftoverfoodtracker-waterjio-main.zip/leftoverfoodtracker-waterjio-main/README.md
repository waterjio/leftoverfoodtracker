# Leftover Food Tracker Project

Welcome to the Leftover Food Tracker project! 

This project is intended to give you the opportunity to practice the concepts that your learned in CPSC 121.

See the [Project Guide](http://tiny.cc/CPSC121A-ProjectGuide) for detailed instructions.
